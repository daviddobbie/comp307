This directory contains an example simple symbolic regression problem.

type these commands to build the program

make clean
make depend
make
 
type ./parsimony_symbolicgp to run

