This example is another symbolic regression example. It uses double
values to try to discover the function
  1.5X^3 + 3.2X^2 + 4.0X - 127.2
To change the function modify the targetFunc values in SymbolicFitness.cpp

To build type

make 

To run type ./symbolic2
