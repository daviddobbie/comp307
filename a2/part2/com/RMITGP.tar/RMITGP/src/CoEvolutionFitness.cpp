/******************************************************************************
 Definition file
 Class:        CoEvolutionFitness 
 Date created: 18/09/2002
 Written by:   Dylan Mawhinney

 See header files for details.
******************************************************************************/

using namespace std;

#include "GPConfig.h"

#include "CoEvolutionFitness.h"

CoEvolutionFitness::CoEvolutionFitness(GPConfig *conf) : Fitness(conf)
{
}
