This directory contains an example of using a grid based population.

To build the program type

make clean
make depend
make

