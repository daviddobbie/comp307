Santa Fe Ant trail problem

The following commands will build the program. If it doesn't work
try changing the file Makefile to suit your environment.
 
make clean
make depend
make
