Core system library, the code in this directory compiles into a
file librmitgp.a.

To compile the library do the following.

type `make'
